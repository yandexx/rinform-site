Книга судьбы
Текстовая игра на конкурс ЗОК '12. 

Автор: Вета (evetaell1@gmail.com)
Программирование: yandexx (yandexx@gmail.com)
Тестирование: cheshire (vd.cheshire@gmail.com)

Платформа: RInform (http://rinform.stormway.ru/)

Для запуска игры крайне предпочтителен проигрыватель Windows Frotz: 
http://mirror.ifarchive.org/if-archive/infocom/interpreters/frotz/WindowsFrotzInstaller.exe
или
http://mirror.ifarchive.org/if-archive/infocom/interpreters/frotz/WindowsFrotz.zip

Альтернативно можно запустить игру на Gargoyle:
http://code.google.com/p/garglk/

